from Mainloop import Mainloop

def main():
    mainloop = Mainloop()

if __name__ == "__main__":
    main()
